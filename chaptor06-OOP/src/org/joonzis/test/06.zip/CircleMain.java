package org.joonzis.test;

public class CircleMain {
	public static void main(String[] args) {
		
		Circle c = new Circle();
		
		c.name = "동그라미";
		c.radius =3.2;
		
		c.info();
	

	
	
}
	
}

