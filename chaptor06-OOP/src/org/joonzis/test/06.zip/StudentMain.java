package org.joonzis.test;

import java.util.Scanner;

public class StudentMain {
	public static void main(String[] args) {
//		클래스 StudentMain
//		- 메소드 : main

		Student s = new Student();
		
		s.input();
		s.output();
	}
}
